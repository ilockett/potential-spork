//
//  ILTestFramework.h
//  ILTestFramework
//
//  Created by Ian Lockett on 29/06/2018.
//  Copyright © 2018 Ian Lockett. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ILTestFramework.
FOUNDATION_EXPORT double ILTestFrameworkVersionNumber;

//! Project version string for ILTestFramework.
FOUNDATION_EXPORT const unsigned char ILTestFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ILTestFramework/PublicHeader.h>
#import <ILTestFramework/ILMessagesAppViewController.h>


