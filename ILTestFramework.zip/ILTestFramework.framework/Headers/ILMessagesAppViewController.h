//
//  ILMessagesAppViewController.h
//  ILTestFramework
//
//  Created by Ian Lockett on 29/06/2018.
//  Copyright © 2018 Ian Lockett. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Messages/Messages.h>

@interface ILMessagesAppViewController : MSMessagesAppViewController

@end
