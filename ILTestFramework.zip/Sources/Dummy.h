//
//  Dummy.h
//  ILiMessage
//
//  Created by Ian Lockett on 02/07/2018.
//  Copyright © 2018 Ian Lockett. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Dummy : NSObject

@end
